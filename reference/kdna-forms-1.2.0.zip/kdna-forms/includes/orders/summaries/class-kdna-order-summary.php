<?php

namespace KDNA_Forms\KDNA_Forms\Orders\Summaries;

use \KDNA_Forms\KDNA_Forms\Orders\KDNA_Order;
use \KDNA_Forms\KDNA_Forms\Orders\Factories\KDNA_Order_Factory;
use \KDNA_Forms\KDNA_Forms\Orders\Exporters\KDNA_Entry_Details_Order_Exporter;

final class KDNA_Order_Summary {

	/**
	 * Contains any specific configurations for rendering the summary, for example showing only a receipt.
	 *
	 * @since 2.6
	 *
	 * @var array
	 */
	public static $configurations;

	/**
	 * Renders the summary markup using the provided data and view.
	 *
	 * @since 2.6
	 *
	 * @param array  $form             The form object.
	 * @param array  $entry            The entry object.
	 * @param string $view             The view to be used for rendering the order.
	 * @param bool   $use_choice_text  If the product field has choices, this decided if the choice text should be retrieved along with the product name or not.
	 * @param bool   $use_admin_labels Whether to use the product admin label or the front end label.
	 * @param bool   $receipt          Whether to show only the line items paid for in the order or all products in the form.
	 *
	 * @return string The summary markup.
	 */
	public static function render( $form, $entry, $view = 'order-summary', $use_choice_text = false, $use_admin_labels = false, $receipt = false ) {
		KDNA_Order_Factory::load_dependencies();

		$order         = KDNA_Order_Factory::create_from_entry( $form, $entry, $use_choice_text, $use_admin_labels, rgar( self::$configurations, 'receipt' ) );
		$order_summary = ( new KDNA_Entry_Details_Order_Exporter( $order ) )->export();
		if ( empty( $order_summary['rows'] ) ) {
			return '';
		}

		$order_summary['labels'] = self::get_labels( $form );
		ob_start();
		include 'views/view-' . $view . '.php'; // nosemgrep audit.php.lang.security.file.inclusion-arg
		return ob_get_clean();

	}

	/**
	 * Return the labels used in the summary view.
	 *
	 * @since 2.6
	 *
	 * @param array form The form object.
	 *
	 * @return array
	 */
	public static function get_labels( $form ) {
		return array(
			'order_label'       => gf_apply_filters( array( 'kdnaform_order_label', $form['id'] ), __( 'Order', 'kdnaforms' ), $form['id'] ),
			'product'           => gf_apply_filters( array( 'kdnaform_product', $form['id'] ), __( 'Product', 'kdnaforms' ), $form['id'] ),
			'product_qty'       => gf_apply_filters( array( 'kdnaform_product_qty', $form['id'] ), __( 'Qty', 'kdnaforms' ), $form['id'] ),
			'product_unitprice' => gf_apply_filters( array( 'kdnaform_product_unitprice', $form['id'] ), __( 'Unit Price', 'kdnaforms' ), $form['id'] ),
			'product_price'     => gf_apply_filters( array( 'kdnaform_product_price', $form['id'] ), __( 'Price', 'kdnaforms' ), $form['id'] ),

		);
	}

}
