<?php

//For backwards compatibility, load wordpress if it hasn't been loaded yet
//Will be used if this file is being called directly
if ( ! class_exists( 'KDNAForms' ) ) {
	for ( $i = 0; $i < $depth = 10; $i ++ ) {
		$wp_root_path = str_repeat( '../', $i );

		if ( file_exists( "{$wp_root_path}wp-load.php" ) ) {
			require_once( "{$wp_root_path}wp-load.php" );
			require_once( "{$wp_root_path}wp-admin/includes/admin.php" );
			break;
		}
	}

	//redirect to the login page if user is not authenticated
	auth_redirect();
}

// If user doesn't have appropriate permissions, die.
if ( ! KDNACommon::current_user_can_any( array( 'kdnaforms_edit_forms', 'kdnaforms_create_form', 'kdnaforms_preview_forms' ) ) ) {
	die( esc_html__( "You don't have adequate permission to preview forms.", 'kdnaforms' ) );
}

// Get form ID.
$form_id = absint( rgget( 'id' ) );

/**
 * Fires when a Form Preview is loaded.
 *
 * The hook fires when a Form Preview is initialized and before it is rendered.
 *
 * @since 2.5
 * @since 2.9 Added the $form_id parameter.
 */
do_action( 'kdnaform_preview_init', $form_id );

// Load form display class.
require_once( KDNACommon::get_base_path() . '/form_display.php' );

// Get form object.
$form       = KDNAFormsModel::get_form_meta( rgget( 'id' ) );
$form_title = rgar( $form, 'title', __( 'Untitled Form', 'kdnaforms' ) );

/* translators: Form preview page title. 1: form title, 2: site title. */
$admin_title = sprintf( __( '%1$s &lsaquo; Form Preview - KDNA Forms &lsaquo; %2$s &#8212; WordPress', 'kdnaforms' ), esc_html( $form_title ), esc_html( get_bloginfo( 'name' ) ) );

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head>
	<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
	<meta http-equiv="Imagetoolbar" content="No" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo esc_html( $admin_title ); ?></title>
	<?php

		// If form exists, enqueue its scripts.
		if ( ! empty( $form ) ) {
			KDNAFormDisplay::enqueue_form_scripts( $form );
		}

		wp_enqueue_script( 'kdnaform_preview' );

		wp_print_head_scripts();

		$styles = array();

		/**
		 * Filters Form Preview Styles.
		 *
		 * This filter modifies the enqueued styles for the Form Preview. Any handles returned in the array
		 * will be loaded in the Preview header (if they've been registered with wp_register_style).
		 *
		 * @since 2.4
		 *
		 * @param array $styles An empty array representing the currently-active styles.
		 * @param array $form An array representing the current Form.
		 *
		 * @return array An array of handles to enqueue in the header.
		 */
		$styles = apply_filters( 'kdnaform_preview_styles', $styles, $form );

		if ( ! empty( $styles ) ) {
			wp_print_styles( $styles );
		}

		/**
		 * Fire before the closing <head> tag of the preview page.
		 *
		 * @since 2.4.19
		 *
		 * @param int $form_id The ID of the form currently being previewed.
		 */
		do_action( 'kdnaform_preview_header', $form_id );

	?>
</head>
<body <?php body_class(); ?>>
<?php
/**
 * Fire after the opening <body> tag of the preview page.
 *
 * @since 2.4.19
 *
 * @param int $form_id The ID of the form currently being previewed.
 */
do_action( 'kdnaform_preview_body_open', $form_id );
?>
<div id="preview_top">
	<div id="preview_hdr">

		<div>

			<span class="toggle_helpers">
				<input type="checkbox" name="showgrid" id="showgrid" value="Y" class="show-grid-input" /><label for="showgrid" class="show-grid-label"><?php esc_html_e( 'display grid', 'kdnaforms' ) ?></label>
				<input type="checkbox" name="showme" id="showme" value="Y" class="show-helpers-input" /><label for="showme" class="show-helpers-label"><?php esc_html_e( 'show structure', 'kdnaforms' ) ?></label>
			</span>
			<!-- Visually hidden page title for screen readers -->
			<h1 style="position: absolute; left: -9999px; width: 1px; height: 1px; overflow: hidden;">
				<?php echo esc_html__( $admin_title );?>
			</h1>
			<h2><?php esc_html_e( 'Form Preview', 'kdnaforms' ) ?> : ID <?php echo esc_html( $form_id ); ?></h2>
		</div>
	</div>
	<div id="preview_note" class="preview_notice">
		<?php esc_html_e( 'Note: This is a simple form preview. This form may display differently when added to your page based on normal inheritance from parent theme styles.', 'kdnaforms' ) ?> <i class="hidenotice" title="<?php esc_html_e( 'dismiss', 'kdnaforms' ) ?>"></i>
	</div>
</div>
<div id="helper_legend_container">
	<ul id="helper_legend">
		<li class="showid">Element ID</li>
		<li class="showclass">Class Name</li>
	</ul>
</div>
<div id="preview_form_container">
	<span class="rule25"></span>
	<span class="rule33"></span>
	<span class="rule50"></span>
	<span class="rule66"></span>
	<span class="rule75"></span>
	<?php echo KDNAForms::get_form( $form_id, true, true, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</div>
<div id="browser_size_info"></div>

<?php

wp_print_footer_scripts();

/**
 * Fires in the footer of a Form Preview page
 *
 * @param int $_GET['id'] The ID of the form currently being previewed
 */
do_action( 'kdnaform_preview_footer', $form_id );
?>

</body>
</html>
